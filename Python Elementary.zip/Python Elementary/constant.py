'''
Provide Constant
'''

PI=3.14
GRAVITY=9.8


